RESET STATE KEEPER v0.8.1 — ENGLISH HUD EDITION
================================================

Purpose
-------
Reset State Keeper preserves selected vehicle state when using BeamNG.drive's vehicle reset (Insert). This build contains the v0.8.0 functionality with an English HUD and English in-game notifications.

Changed in v0.8.1
-----------------
- The HUD starts collapsed to its small fuel icon when the app is created or reinitialized. Click the icon to expand it.
- Vehicle-state handling, reset controls, fuel controls and saved settings are unchanged.

Features
--------
- Preserves supported fuel storage levels, engine oil/coolant temperatures and other exposed temperature values, headlight mode, and hazard-light state after resetting a vehicle.
- Keeps separate cached states for recognized player-spawned vehicles.
- Switching between existing player vehicles preserves each vehicle's own cached state.
- When the current vehicle is replaced and the previous object is removed, its cache is discarded and defaults are applied to the replacement: tanks are filled, accessible temperatures are reset, headlights and hazard lights are switched off.
- AI traffic is excluded from state tracking and state-restoration commands.
- F10 or the HUD Reset button clears cached states; the next reset uses the game's normal reset behavior.
- HUD fuel controls show available tank capacity/current amount, allow a manual amount in liters, Full Tank, and 25/50/75/100% presets.
- Fuel-consumption multiplier can be adjusted live; quick presets are x1, x2, x5, x10 and x20, with manual input up to x100.
- Collapsible HUD.

Installation
------------
1. Close BeamNG.drive.
2. Remove previous Reset State Keeper ZIPs, including the Russian build and v0.8.0, to avoid duplicate UI apps or overlapping paths.
3. Place Reset_State_Keeper_BeamNG_v0.8.1_EN.zip in the BeamNG.drive user folder's mods directory. Do not extract the ZIP.
4. Start the game, open ESC -> UI Apps -> Add App, and add "Reset State Keeper — Fuel Control".

Configuration
-------------
Fuel consumption settings are stored in:
settings/resetStateKeeper.json

Example:
{
  "fuelConsumptionMultiplier": 10.0
}

Notes and limitations
---------------------
- Cached vehicle states are runtime snapshots for the current game session; they are not permanent vehicle saves across game restarts.
- Fuel capacity display and fuel adjustment depend on fields exposed by the vehicle. Some custom vehicles may not provide supported tank data.
- Reset State Keeper does not repair mechanical damage or fix an engine disabled by damage.
- Third-party vehicles can expose different storage and temperature parameters; unusual configurations should be tested in-game.

Compatibility
-------------
The last game version specified for this project is BeamNG.drive 0.39.4.0; compatibility with newer versions is not confirmed. The archive and scripts are statically checked, but only an in-game run can validate behavior on specific vehicles.

Removing the Mod
----------------
Close the game and remove the ZIP from the mods directory. You may keep or manually delete settings/resetStateKeeper.json.
